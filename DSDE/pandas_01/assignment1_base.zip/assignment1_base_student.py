def main():
    file = input()
    func = input()

    if func == 'Q1':
        # Do something
    elif func == 'Q2':
        # Do something
    elif func == 'Q3':
        # Do something
    else:
        # Do something

if __name__ == "__main__":
    main()